#!/bin/bash


while true; do

echo "----------------------"
echo "MENU DEL SCRIPT"
echo "----------------------"
echo "1. Datos de red del equipo" #LISTO
echo "2. Estado del servicio" #LISTO
echo "3. Instalación del servicio" #LISTO MENOS ANSIBLE
echo "4. Eliminación del servicio en local" #LISTO
echo "5. Puesta en marcha del servicio" #LISTO
echo "6. Parada del servicio" #LISTO
echo "7. Configuración del servicio" #PENDIENTE
echo "8. Salir"
echo ""
read -p "Dime una opción: " opcion

echo ""

case $opcion in

1)
IP=$(ifconfig enp0s3 | grep inet | grep -v inet6 | awk -F " " '{print$2}')
Mascara=$(ifconfig enp0s3 | grep inet | grep -v inet6 | awk -F " " '{print$4}')
Broadcast=$(ifconfig enp0s3 | grep inet | grep -v inet6 | awk -F " " '{print$6}')
echo "La IP de red es: $IP"
echo "La máscara de red es: $Mascara"
echo "El broadcast de red es: $Broadcast"
echo ""

;;

2)

read -p "Deseas verificar el estado del servicio en docker o en el propio sistema (docker,sistema,ansible): " respuesta
	echo ""
if [ "$respuesta" == "sistema" ] || [ "$respuesta" == "SISTEMA" ];
then

	comprobacion1=$(systemctl status bind9 2> /dev/null | grep "Active: active" | awk -F " " '{print$1,$2,$3}' | wc -l)

if [ "$comprobacion1" -eq 1 ];then 

	echo "El servicio está activo e instalado"


	comprobacion2=$(systemctl status bind9 2> /dev/null | grep "Active: inactive" | awk -F " " '{print$1,$2,$3}' | wc -l)

elif [ "$comprobacion2" -eq 1 ];then

	echo "El servicio está inactivo"

	comprobacion3=$(systemctl status bind9 2>/dev/null)
elif [ -z "$comprobacion3" ];then

	echo "El servicio no está instalado"

fi

if [ "$respuesta" == "docker" ] || [ "$respuesta" == "DOCKER" ];
then
	comprobar_docker=$(docker ps | grep "bind9" | wc -l)
	if [ $comprobar_docker -eq 1 ];
	then
		echo "El servicio en Docker se encuentra activo"
		echo ""
	else
		echo "El servicio no se encuentra activo en Docker"
		echo ""
	fi
fi

elif [ "$respuesta" == "ansible" ] || [ "$respuesta" == "ANSIBLE" ];
then
	status=$(ansible webservers -m command -a "/bin/systemctl status bind9" | grep "Active: active")
	if [ -z "$status" ];then
                echo "Servicio no iniciado"
        else
                echo "Servicio iniciado"
    fi
fi
;;

3)

while true; do
echo "----------------------"
echo "MENU DE INSTALACION"
echo "----------------------"
echo "1. Con comandos"
echo "2. Con Ansible"
echo "3. Con Docker"
echo "4. Salir"
echo ""
read -p "Dime como quieres instalar el servicio: " opcion2 

echo ""

	case $opcion2 in

	1)
	# Función para verificar si BIND9 está instalado
check_bind9_installed() {
    dpkg -s bind9 &> /dev/null
}

# Función para manejar errores
error() {
    echo "Error: $1"
    exit 1
}

# Verificar si BIND9 ya está instalado
if check_bind9_installed; then
    echo "BIND9 ya está instalado."
    exit 0
fi

# Instalar BIND9
echo "Instalando BIND9..."
if ! sudo apt update; then
   error "No se pudo actualizar el sistema."
fi

if ! sudo apt install -y bind9; then
    error "No se pudo instalar BIND9."
fi

# Verificar si la instalación fue exitosa
if check_bind9_installed; then
    echo "BIND9 se ha instalado correctamente."
else
    error "BIND9 no se instaló correctamente."
fi

exit 0


	;;

	2)
        conn=$(ansible webservers -m ping)
        status=$(ansible webservers -m command -a "/bin/systemctl status bind9" | grep "Active: active")
        if [ ! "$conn" ];then
                echo "Conexion Fallida"
        else
                echo "Conexion Establecida"
                if [ -z "$status" ];then
                        echo "Servicio no instalado"
                        echo "Procedemos a instalarlo"
                        ansible-playbook -v /etc/ansible/playbook_install_bind9.yml --extra-vars "ansible_sudo_pass=nando"
                        echo "Servicio instalado"
                else
                        echo "Servicio instalado"
                fi
        fi

	;;

	3)

	if docker build -t bind9 . 2> /dev/null;
	then
		echo "El servicio fue instalado correctamente"
		echo ""
		echo "Presione las teclas CTRL + P + Q"
		echo ""
		correr_docker=$(docker run -it --name bind9 bind9 2> /dev/null | wc -l)
		if [ "$correr_docker" -eq 1 ];
		then
			echo ""
		else
			echo "El contenedor se ha instalado o ya se encuentra instalado e inicializado"
		fi
	else
		echo "Contenedor no instalado correctamente. Compruebe su conexión a internet"
		echo ""
	fi
	;;

	4)
	echo "Saliendo del instalador..."
	echo ""
	break

	;;

	*)
	echo "Elija una opcion del menú"
	echo ""
	;;





	esac
done


;;

4)

read -p "Deseas eliminar el servicio en el sistema o el contenedor (sistema,docker,ansible): " respuesta

if [ "$respuesta" == "sistema" ];
then

comprobar_bind(){
	if  dpkg -l | grep "bind9" >/dev/null;then
	return 0
	#BIND9 esta instalado

	else 
	return 1
	#BIND9 no esta instalado
	fi
	}

	if comprobar_bind; then
	echo "Bind9 esta instalado. ELiminando ..."
	echo ""

	sudo apt remove --purge -y bind9
	echo ""
	echo "Bind9 Eliminado correctamente"
	else

	echo "Bind9 no está instalado"

	fi

elif [ "$respuesta" == "docker" ];
then
	docker rm bind9 > /dev/null
	docker rmi bind9 > /dev/null
	echo "El docker ha sido desinstalado correctamente. En caso de que no se haya eliminado, primero se deberá de detemer el contenedor"

elif [ "$respuesta" == "ansible" ]; then
	conn=$(ansible webservers -m ping)
	status=$(ansible webservers -m command -a "/bin/systemctl status bind9" | grep "Active: active")
	if [ ! "$conn" ];then
		echo "Conexion Fallida"
	else
			echo "Conexion Establecida"
			if [ -z "$status" ];then
					echo "El servicio ya esta desinstalado"
			else
					echo "Servicio instalado"
					echo "Procedemos a desinstalarlo"
					ansible-playbook -v /etc/ansible/playbook_uninstall_bind9.yml --extra-vars "ansible_sudo_pass=nando"
					echo "Servicio desinstalado"
			fi
	fi
fi
;;

5)

read -p "Deseas iniciar el servicio en el sistema o el contenedor (sistema,docker,ansible): " respuesta

if [ "$respuesta" == "sistema" ];
then

comprobacion=$(systemctl status bind9 2> /dev/null | grep "Active: inactive" | awk -F " " '{print$1,$2,$3}' | wc -l)

if [ $comprobacion -eq 1 ];then 

sudo systemctl start bind9
echo "Servicio arrancado con éxito"

else 
echo "El servicio no se ha arrancado"

fi

elif [ "$respuesta" == "docker" ];
then
	docker start bind9 > /dev/null
	echo "El servicio de bind9 en docker ha sido iniciado con éxito"

elif [ "$respuesta" == "ansible" ];
then
	conn=$(ansible webservers -m ping)
	status=$(ansible webservers -m command -a "/bin/systemctl status bind9" | grep "Stopped BIND Domain Name Server")
	if [ ! "$conn" ];then
		echo "Conexion Fallida"
	else
			echo "Conexion Establecida"
			if [ -z "$status" ];then
					echo "Servicio iniciado"
			else
					echo "Servicio no iniciado"
					echo "Procedemos a iniciarlo"
					ansible-playbook -v /etc/ansible/playbook_start_bind9.yml --extra-vars "ansible_sudo_pass=nando"
					echo "Servicio iniciado"
			fi
	fi

fi

;;

6)

read -p "Deseas parar el servicio en el sistema o el contenedor (sistema,docker,ansible): " respuesta

if [ "$respuesta" == "sistema" ];
then

comprobacion=$(systemctl status bind9 2> /dev/null | grep "Active: active" | awk -F " " '{print$1,$2,$3}' | wc -l)

if [ $comprobacion -eq 1 ];then 

sudo systemctl stop bind9
echo "Servicio parado con éxito"

else 
echo "El servicio no se ha detenido"

fi

elif [ "$respuesta" == "docker" ];
then
	docker stop bind9 > /dev/null
	echo "El servicio de bind9 en docker ha sido detenido con éxito"

elif [ "$respuesta" == "ansible" ];
then
	conn=$(ansible webservers -m ping)
	status=$(ansible webservers -m command -a "/bin/systemctl status bind9" | grep "Stopped BIND Domain Name Server")
	if [ ! "$conn" ];then
		echo "Conexion Fallida"
	else
			echo "Conexion Establecida"
			if [ -z "$status" ];then
					echo "Servicio activo"
					echo "Procedemos a pararlo"
					ansible-playbook -v /etc/ansible/playbook_stop_bind9.yml --extra-vars "ansible_sudo_pass=nando"
					echo "Servicio parado"
			else
					echo "Servicio ya esta parado"
			fi
	fi


fi

;;

7)
if [ ! -d /etc/bind ];
    then
        echo "Bind no instalado"
    else
        echo "Bind instalado"
        echo ""
        rm /etc/bind/named.conf.options
        printf 'acl "trusted" {\n 172.16.114.80;\n 172.16.115.90;\n 172.16.114.100;\n 172.16.115.110;\n };\n\n options {\n directory "/var/cache/bind";\n\n recursion yes;\n allow-recursion { trusted; };\n listen-on { 172.16.114.80; };\n allow-transfer { none; };\n\n forwarders {\n 8.8.8.8;\n 8.8.4.4;\n };\n\n };' > /etc/bind/named.conf.options
        echo "Debes colocar en la interfaz de red de tu ordenador o servidor lo siguiente:"
        echo ""
        echo "IP: 172.16.114.80"
        echo "Máscara: 255.255.254.0"
        echo "Gateway: 172.16.114.1"
        echo "DNS Primario: 172.16.114.80"
        echo "DNS Secundario: 172.16.115.90"
        echo ""
        echo "Debes ahora reiniciar tu ordenador para que los cambios se hagan efectivos"

    fi
;;


8)
echo "Saliendo del menú..."
echo " "
break

;;

*)

echo "Esa opción no existe, elija una del menú"
echo " "
;;
esac

done
